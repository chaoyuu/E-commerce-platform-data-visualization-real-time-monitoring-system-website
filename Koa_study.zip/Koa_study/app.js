const Koa = require('koa');

const app = new Koa();

app.use((ctx,next) => {
   
    // console.log(ctx.request.url);
    console.log('第一层中间件...1');
    ctx.response.body ='hello';
    next();
    console.log('第一层中间件...2');

});
app.use(async (ctx,next) => {
    console.log('第二层中间件...1');
    const ret = await next();
    console.log(ret);
    // next();
    console.log('第二层中间件...2');


});

//
app.use((ctx,next) => {
    console.log('第三层中间件');
    return ' i love you'

    
});
//绑定端口号 3000

app.listen(3000,() =>{

    
    console.log('启动了哦主人！！！');
})
